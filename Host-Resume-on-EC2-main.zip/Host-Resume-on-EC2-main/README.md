# Host Your Resume on AWS EC2 with a CI/CD Setup Using GitHub Actions
